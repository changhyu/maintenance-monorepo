declare const contains: (arr: any[], value: any) => boolean;
export default contains;
