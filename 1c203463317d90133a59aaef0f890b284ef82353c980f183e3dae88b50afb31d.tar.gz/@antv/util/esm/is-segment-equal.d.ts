declare const _default: (obj1: any, obj2: any) => boolean;
export default _default;
