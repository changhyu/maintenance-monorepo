declare const filter: <T>(arr: T[], func: (v: T, idx: number) => boolean) => T[];
export default filter;
