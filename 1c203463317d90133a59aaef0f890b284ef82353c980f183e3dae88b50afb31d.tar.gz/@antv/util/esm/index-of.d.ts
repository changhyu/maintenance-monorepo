declare const indexOf: <T>(arr: T[], obj: T) => number;
export default indexOf;
