declare const lowerCase: (str: string) => string;
export default lowerCase;
