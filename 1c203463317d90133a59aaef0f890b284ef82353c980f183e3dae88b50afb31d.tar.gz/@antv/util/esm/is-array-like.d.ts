declare const isArrayLike: (value: any) => boolean;
export default isArrayLike;
