export default function requestAnimationFrame(fn: FrameRequestCallback): any;
