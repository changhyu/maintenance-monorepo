declare const isNull: (value: any) => value is null;
export default isNull;
