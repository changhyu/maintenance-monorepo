declare const augment: (...args: any[]) => void;
export default augment;
