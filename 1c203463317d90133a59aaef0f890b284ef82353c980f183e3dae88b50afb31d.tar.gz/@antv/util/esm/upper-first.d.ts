declare const upperFirst: (value: string) => string;
export default upperFirst;
