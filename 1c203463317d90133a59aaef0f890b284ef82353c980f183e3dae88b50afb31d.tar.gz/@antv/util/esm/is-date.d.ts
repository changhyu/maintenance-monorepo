declare const isDate: (value: any) => value is Date;
export default isDate;
