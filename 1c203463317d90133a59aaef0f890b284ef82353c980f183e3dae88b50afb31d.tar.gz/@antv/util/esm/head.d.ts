export default function head(o: unknown): any;
