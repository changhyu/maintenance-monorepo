declare const _default: (f: Function, resolver?: (...args: any[]) => string) => {
    (...args: any[]): any;
    cache: Map<any, any>;
};
/**
 * _.memoize(calColor);
 * _.memoize(calColor, (...args) => args[0]);
 * @param f
 * @param resolver
 */
export default _default;
