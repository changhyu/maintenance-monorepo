declare const _default: (obj: object, key: any) => boolean;
export default _default;
