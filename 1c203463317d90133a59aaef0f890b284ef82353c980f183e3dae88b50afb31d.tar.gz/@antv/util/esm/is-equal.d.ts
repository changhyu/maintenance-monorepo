declare const isEqual: (value: any, other: any) => boolean;
export default isEqual;
