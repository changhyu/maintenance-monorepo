declare const _default: <T = object>(value: any) => value is T;
export default _default;
