declare function findIndex<T>(arr: T[], predicate: (item: T, idx?: number) => boolean, fromIndex?: number): number;
export default findIndex;
