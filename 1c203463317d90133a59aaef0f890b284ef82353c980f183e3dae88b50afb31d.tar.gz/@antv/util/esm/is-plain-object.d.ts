declare const isPlainObject: (value: any) => value is object;
export default isPlainObject;
