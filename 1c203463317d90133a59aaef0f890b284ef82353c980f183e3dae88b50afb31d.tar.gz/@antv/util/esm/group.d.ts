declare const _default: <T>(data: T[], condition: string | string[] | ((v: T) => string)) => T[][];
export default _default;
