declare const _default: <T>(v: T) => T;
export default _default;
