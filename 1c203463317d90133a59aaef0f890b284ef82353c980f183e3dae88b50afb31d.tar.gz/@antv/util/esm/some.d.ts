/**
 * 只要有一个满足条件就返回 true
 * @param arr
 * @param func
 */
declare const some: <T>(arr: T[], func: (v: T, idx?: number) => any) => boolean;
export default some;
