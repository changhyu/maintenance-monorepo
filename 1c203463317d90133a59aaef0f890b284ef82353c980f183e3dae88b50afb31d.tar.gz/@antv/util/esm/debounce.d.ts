declare function debounce(func: Function, wait?: number, immediate?: boolean): () => void;
export default debounce;
