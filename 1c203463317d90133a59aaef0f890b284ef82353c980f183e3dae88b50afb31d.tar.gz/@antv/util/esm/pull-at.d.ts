declare const pullAt: <T>(arr: T[], indexes: number[]) => T[];
export default pullAt;
