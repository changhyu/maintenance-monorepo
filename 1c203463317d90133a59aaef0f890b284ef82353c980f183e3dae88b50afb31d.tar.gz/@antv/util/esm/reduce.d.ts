import { ObjectType } from './types';
declare const reduce: <T, G>(arr: ObjectType<T> | G[], fn: (result: T, data: G, idx: string | number) => T, init: T) => T;
export default reduce;
