declare const isRegExp: (str: any) => str is RegExp;
export default isRegExp;
