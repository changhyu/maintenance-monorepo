declare const upperCase: (str: string) => string;
export default upperCase;
