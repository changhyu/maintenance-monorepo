declare const mod: (n: number, m: number) => number;
export default mod;
