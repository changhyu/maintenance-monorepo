declare function isMatch(obj: any, attrs: any): boolean;
export default isMatch;
