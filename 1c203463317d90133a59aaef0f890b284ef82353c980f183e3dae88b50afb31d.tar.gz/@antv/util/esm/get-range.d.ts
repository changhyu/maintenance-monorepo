export interface RangeType {
    readonly min: number;
    readonly max: number;
}
declare const getRange: (values: number[]) => RangeType;
export default getRange;
