declare const deepMix: (rst: any, ...args: any[]) => any;
export default deepMix;
