export default function isNumberEqual(a: number, b: number, precision?: number): boolean;
