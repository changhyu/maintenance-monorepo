declare const fixedBase: (v: number, base: number | string) => number;
export default fixedBase;
