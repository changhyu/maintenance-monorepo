declare const clone: (obj: any) => any;
export default clone;
