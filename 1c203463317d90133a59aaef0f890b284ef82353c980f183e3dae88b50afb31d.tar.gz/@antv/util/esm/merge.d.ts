declare const _default: <T>(dataArray: T[]) => T[];
/**
 * 将数组展开
 * todo 和 flatten 是一个意思吧？@绝云
 * @param dataArray
 */
export default _default;
