declare const isBoolean: (value: any) => value is boolean;
export default isBoolean;
