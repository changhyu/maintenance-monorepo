declare const _default: <T>(object: {
    [key: string]: T;
}, func?: (value: T, key: string) => any) => {
    [key: string]: any;
};
export default _default;
