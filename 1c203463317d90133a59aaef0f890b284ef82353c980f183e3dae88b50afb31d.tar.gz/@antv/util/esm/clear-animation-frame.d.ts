export default function cancelAnimationFrame(handler: number): void;
