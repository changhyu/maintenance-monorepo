declare const isUndefined: (value: any) => value is undefined;
export default isUndefined;
