declare function isEmpty(value: any): boolean;
export default isEmpty;
