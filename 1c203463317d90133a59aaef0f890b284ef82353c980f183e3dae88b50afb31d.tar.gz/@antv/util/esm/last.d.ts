export default function last(o: unknown): any;
