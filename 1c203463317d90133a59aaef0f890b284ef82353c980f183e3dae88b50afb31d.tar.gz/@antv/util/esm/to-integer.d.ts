export default parseInt;
