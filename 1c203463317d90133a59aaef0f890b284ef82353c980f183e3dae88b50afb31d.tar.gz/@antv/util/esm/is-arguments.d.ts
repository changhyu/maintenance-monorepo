declare const isArguments: (value: any) => boolean;
export default isArguments;
