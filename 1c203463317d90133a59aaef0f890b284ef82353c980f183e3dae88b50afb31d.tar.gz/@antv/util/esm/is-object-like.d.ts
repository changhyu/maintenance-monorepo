declare const isObjectLike: (value: any) => value is object;
export default isObjectLike;
