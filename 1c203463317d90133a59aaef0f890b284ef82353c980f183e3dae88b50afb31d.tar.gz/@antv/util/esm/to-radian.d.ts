declare const toRadian: (degree: number) => number;
export default toRadian;
