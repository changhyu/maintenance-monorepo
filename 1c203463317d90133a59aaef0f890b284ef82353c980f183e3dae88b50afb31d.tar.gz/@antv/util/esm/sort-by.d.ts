export interface ObjectType<T> {
    [key: string]: T;
}
declare function sortBy<T>(arr: ObjectType<T>[], key: Function): ObjectType<T>[];
declare function sortBy<T>(arr: ObjectType<T>[], key: string): ObjectType<T>[];
declare function sortBy<T>(arr: ObjectType<T>[], key: string[]): ObjectType<T>[];
export default sortBy;
