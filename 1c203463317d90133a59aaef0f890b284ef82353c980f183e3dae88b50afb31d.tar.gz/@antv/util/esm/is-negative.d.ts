declare const isNegative: (num: any) => boolean;
export default isNegative;
