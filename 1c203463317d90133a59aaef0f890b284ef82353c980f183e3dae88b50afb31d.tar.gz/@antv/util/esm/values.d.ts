declare const values: (obj: any) => any;
export default values;
