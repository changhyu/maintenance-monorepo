declare const remove: <T>(arr: T[], predicate: (value: T, idx: number, arr?: T[]) => boolean) => T[];
export default remove;
