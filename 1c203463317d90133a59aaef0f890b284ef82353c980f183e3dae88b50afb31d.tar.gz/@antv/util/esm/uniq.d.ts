export default function uniq(arr: any[], cache?: Map<any, any>): any[];
