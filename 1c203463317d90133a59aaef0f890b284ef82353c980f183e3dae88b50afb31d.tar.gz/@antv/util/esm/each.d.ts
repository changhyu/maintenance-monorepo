declare function each(elements: any[] | object, func: (v: any, k: any) => any): void;
export default each;
