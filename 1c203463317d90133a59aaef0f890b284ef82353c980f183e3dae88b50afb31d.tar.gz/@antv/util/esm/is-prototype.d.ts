declare const isPrototype: (value: any) => boolean;
export default isPrototype;
