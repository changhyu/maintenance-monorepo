/**
 * 将数据分组成 map
 * @param data
 * @param condition
 */
export default function groupToMap(data: any, condition: string[] | string | ((row: any) => string)): import("./group-by").ObjectType<any> | {
    0: any;
};
