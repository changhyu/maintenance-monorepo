export default function size(o: unknown): number;
