declare const isInteger: (number: unknown) => boolean;
export default isInteger;
