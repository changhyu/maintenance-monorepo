export default function (value: any): value is number;
