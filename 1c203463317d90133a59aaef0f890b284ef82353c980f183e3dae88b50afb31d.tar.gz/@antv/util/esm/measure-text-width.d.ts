import type { Properties } from 'csstype';
export declare type Font = Pick<Properties, 'fontFamily' | 'fontWeight' | 'fontStyle' | 'fontVariant'> & {
    fontSize?: number;
};
declare const _default: {
    (...args: any[]): any;
    cache: Map<any, any>;
};
/**
 * 计算文本的宽度
 */
export default _default;
