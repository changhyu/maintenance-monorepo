export default function mix<Base, A, B, C>(dist: Base & A & B & C, src1?: A, src2?: B, src3?: C): Base & A & B & C;
