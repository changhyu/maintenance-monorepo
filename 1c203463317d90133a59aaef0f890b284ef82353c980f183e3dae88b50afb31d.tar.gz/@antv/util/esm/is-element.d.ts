/**
 * 判断是否HTML元素
 * @return {Boolean} 是否HTML元素
 */
declare const isElement: (o: any) => boolean;
export default isElement;
