export interface OptionsType {
    leading?: boolean;
    trailing?: boolean;
}
declare const _default: (func: Function, wait: number, options: OptionsType) => Function;
export default _default;
