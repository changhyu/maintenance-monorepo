declare function numberToColor(num: number): string;
export default numberToColor;
