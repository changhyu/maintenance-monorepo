declare const isPositive: (num: any) => boolean;
export default isPositive;
