declare const isError: (value: any) => value is Error;
export default isError;
