export interface ObjectType<T> {
    [key: string]: T;
}
declare function substitute<T>(str: string, o: ObjectType<T>): string;
export default substitute;
