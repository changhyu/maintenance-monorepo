declare const _default: (obj: object, value: any) => boolean;
export default _default;
