declare function endsWith(arr: string, e: string): boolean;
declare function endsWith<T>(arr: T[], e: T): boolean;
export default endsWith;
