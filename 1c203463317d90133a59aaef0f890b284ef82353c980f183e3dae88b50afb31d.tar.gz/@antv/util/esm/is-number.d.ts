declare const isNumber: (value: any) => value is number;
export default isNumber;
