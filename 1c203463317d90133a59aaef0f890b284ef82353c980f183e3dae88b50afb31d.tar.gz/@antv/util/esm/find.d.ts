declare function find<T>(arr: T[], predicate: Function): T;
declare function find<T>(arr: T[], predicate: object): T;
export default find;
