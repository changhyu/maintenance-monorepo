declare const _default: (obj: any, key: string | any[], defaultValue?: any) => any;
/**
 * https://github.com/developit/dlv/blob/master/index.js
 * @param obj
 * @param key
 * @param defaultValue
 */
export default _default;
