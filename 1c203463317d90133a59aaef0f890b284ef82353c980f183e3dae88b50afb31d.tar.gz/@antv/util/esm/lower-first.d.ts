declare const lowerFirst: (value: string) => string;
export default lowerFirst;
