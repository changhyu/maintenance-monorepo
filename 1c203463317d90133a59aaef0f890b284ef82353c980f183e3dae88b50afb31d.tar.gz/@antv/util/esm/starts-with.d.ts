declare function startsWith(arr: string, e: string): boolean;
declare function startsWith<T>(arr: T[], e: T): boolean;
export default startsWith;
