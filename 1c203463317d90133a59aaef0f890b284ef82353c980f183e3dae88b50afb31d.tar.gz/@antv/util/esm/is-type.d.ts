declare const isType: (value: any, type: string) => boolean;
export default isType;
