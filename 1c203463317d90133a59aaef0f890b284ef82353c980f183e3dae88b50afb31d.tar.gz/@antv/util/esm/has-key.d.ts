import has from './has';
export default has;
