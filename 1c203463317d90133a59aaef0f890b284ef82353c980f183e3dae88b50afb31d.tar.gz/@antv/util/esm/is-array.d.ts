declare const _default: (value: any) => value is any[];
export default _default;
