declare const isDecimal: (num: any) => boolean;
export default isDecimal;
