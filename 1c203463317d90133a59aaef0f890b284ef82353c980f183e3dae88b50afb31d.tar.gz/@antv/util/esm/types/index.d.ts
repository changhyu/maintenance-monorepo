export interface ObjectType<T> {
    [key: string]: T;
}
