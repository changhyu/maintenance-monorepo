declare const extend: (subclass: any, superclass: any, overrides?: any, staticOverrides?: any) => any;
export default extend;
