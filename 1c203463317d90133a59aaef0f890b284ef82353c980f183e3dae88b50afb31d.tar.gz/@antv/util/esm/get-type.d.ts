declare const getType: (value: any) => string;
export default getType;
