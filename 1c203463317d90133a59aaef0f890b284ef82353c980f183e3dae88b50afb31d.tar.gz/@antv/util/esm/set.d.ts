declare const _default: (obj: any, path: string | any[], value: any) => any;
/**
 * https://github.com/developit/dlv/blob/master/index.js
 * @param obj
 * @param path
 * @param value
 */
export default _default;
