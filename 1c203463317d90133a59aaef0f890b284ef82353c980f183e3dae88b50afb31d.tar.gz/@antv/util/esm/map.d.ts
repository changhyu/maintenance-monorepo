declare const map: <T, G>(arr: T[], func: (v: T, idx: number) => G) => G[];
export default map;
