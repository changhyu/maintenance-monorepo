declare const isOdd: (num: any) => boolean;
export default isOdd;
