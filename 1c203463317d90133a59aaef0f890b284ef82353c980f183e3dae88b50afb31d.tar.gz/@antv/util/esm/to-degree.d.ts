declare const toDegree: (radian: number) => number;
export default toDegree;
