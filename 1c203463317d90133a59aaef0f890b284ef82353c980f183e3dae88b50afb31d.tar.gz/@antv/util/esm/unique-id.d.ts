declare const _default: (prefix?: string) => string;
export default _default;
