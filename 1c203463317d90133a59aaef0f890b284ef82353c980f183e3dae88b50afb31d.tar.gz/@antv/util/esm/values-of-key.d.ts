declare const _default: (data: any[], name: string) => any[];
export default _default;
