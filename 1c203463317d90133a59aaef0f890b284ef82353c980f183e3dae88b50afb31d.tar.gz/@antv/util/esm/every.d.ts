/**
 * 只要有一个不满足条件就返回 false
 * @param arr
 * @param func
 */
declare const every: <T>(arr: T[], func: (v: T, idx?: number) => any) => boolean;
export default every;
