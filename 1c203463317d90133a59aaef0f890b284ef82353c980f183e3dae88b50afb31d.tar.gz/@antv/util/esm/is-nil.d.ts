declare const isNil: (value: any) => value is null;
export default isNil;
