declare const _default: (str: any) => str is string;
export default _default;
