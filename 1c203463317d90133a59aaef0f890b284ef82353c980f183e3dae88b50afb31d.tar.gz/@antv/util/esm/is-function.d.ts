declare const _default: (value: any) => value is Function;
export default _default;
