declare const _default: (value: any) => string;
export default _default;
