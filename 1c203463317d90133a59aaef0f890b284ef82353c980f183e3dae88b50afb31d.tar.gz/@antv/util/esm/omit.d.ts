import { ObjectType } from './types';
declare const _default: <T>(obj: ObjectType<T>, keys: string[]) => ObjectType<T>;
export default _default;
