declare const isEven: (num: any) => boolean;
export default isEven;
