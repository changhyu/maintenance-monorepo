declare const union: (...sources: any[]) => any[];
export default union;
