declare const clamp: (a: number, min: number, max: number) => number;
export default clamp;
