declare const pull: <T>(arr: T[], ...values: any[]) => T[];
export default pull;
