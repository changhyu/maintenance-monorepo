declare const keys: (obj: any) => any[];
export default keys;
