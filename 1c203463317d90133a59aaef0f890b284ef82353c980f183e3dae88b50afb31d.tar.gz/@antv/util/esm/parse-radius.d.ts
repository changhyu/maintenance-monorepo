export interface RadiusType {
    r1: number;
    r2: number;
    r3: number;
    r4: number;
}
declare function parseRadius(radius: number): RadiusType;
declare function parseRadius(radius: number[]): RadiusType;
export default parseRadius;
