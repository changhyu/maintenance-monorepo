declare const firstValue: (data: object[], name: string) => any;
export default firstValue;
