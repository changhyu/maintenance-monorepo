:::danger Deprecated

This rule has been deprecated in favour of the [`import/no-duplicates`](https://github.com/import-js/eslint-plugin-import/blob/HEAD/docs/rules/no-duplicates.md) rule.

:::

<!--
This doc file has been left on purpose because `import/no-duplicates` is
commonly requested. This exists to help direct people to the replacement rule.

Note that there is no actual way to get to this page in the normal navigation,
so end-users will only be able to get to this page from the search bar.
-->
