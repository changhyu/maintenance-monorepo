import React from 'react';
declare const createNode: (children: React.ReactElement, type?: string, uuid?: string) => HTMLDivElement;
export default createNode;
