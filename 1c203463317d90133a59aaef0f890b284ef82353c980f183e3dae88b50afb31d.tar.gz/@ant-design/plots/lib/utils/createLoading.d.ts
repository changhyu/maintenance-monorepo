import React from 'react';
interface Props {
    /**
     * @title 主题
     * @description 配置主题颜色
     * @title.en_US Theme
     * @description.en_US Configure theme colors
     */
    theme?: string | object;
    /**
     * @title 加载模板
     * @description 图表加载
     * @title.en_US Load template
     * @description.en_US Chart loading
     */
    loadingTemplate?: React.ReactElement;
}
declare const ChartLoading: ({ loadingTemplate, theme }: Props) => React.JSX.Element;
export default ChartLoading;
