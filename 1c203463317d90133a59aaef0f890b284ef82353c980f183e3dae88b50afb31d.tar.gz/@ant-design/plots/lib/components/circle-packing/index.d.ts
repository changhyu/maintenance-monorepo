import React from 'react';
import { CirclePackingOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface CirclePackingConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const CirclePackingChart: React.ForwardRefExoticComponent<CirclePackingConfig & React.RefAttributes<unknown>>;
export default CirclePackingChart;
