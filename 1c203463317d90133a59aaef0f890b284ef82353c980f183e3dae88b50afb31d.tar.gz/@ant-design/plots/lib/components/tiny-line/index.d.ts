import React from 'react';
import { TinyLineOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface TinyLineConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const TinyLineChart: React.ForwardRefExoticComponent<TinyLineConfig & React.RefAttributes<unknown>>;
export default TinyLineChart;
