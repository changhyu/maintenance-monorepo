import React from 'react';
import { WaterfallOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface WaterfallConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const WaterfallChart: React.ForwardRefExoticComponent<WaterfallConfig & React.RefAttributes<unknown>>;
export default WaterfallChart;
