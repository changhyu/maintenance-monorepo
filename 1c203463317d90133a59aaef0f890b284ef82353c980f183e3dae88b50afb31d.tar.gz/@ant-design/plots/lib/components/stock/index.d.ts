import React from 'react';
import { StockOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface StockConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const StockChart: React.ForwardRefExoticComponent<StockConfig & React.RefAttributes<unknown>>;
export default StockChart;
