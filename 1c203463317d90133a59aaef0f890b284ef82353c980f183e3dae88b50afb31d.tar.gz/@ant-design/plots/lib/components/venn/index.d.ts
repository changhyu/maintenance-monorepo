import React from 'react';
import { VennOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface VennConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const VennChart: React.ForwardRefExoticComponent<VennConfig & React.RefAttributes<unknown>>;
export default VennChart;
