import React from 'react';
import { BidirectionalBarOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface BidirectionalBarConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const BidirectionalBarChart: React.ForwardRefExoticComponent<BidirectionalBarConfig & React.RefAttributes<unknown>>;
export default BidirectionalBarChart;
