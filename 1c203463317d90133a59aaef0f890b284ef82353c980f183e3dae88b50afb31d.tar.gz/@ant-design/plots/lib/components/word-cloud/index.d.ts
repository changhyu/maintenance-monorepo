import React from 'react';
import { WordCloudOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface WordCloudConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const WordCloudChart: React.ForwardRefExoticComponent<WordCloudConfig & React.RefAttributes<unknown>>;
export default WordCloudChart;
