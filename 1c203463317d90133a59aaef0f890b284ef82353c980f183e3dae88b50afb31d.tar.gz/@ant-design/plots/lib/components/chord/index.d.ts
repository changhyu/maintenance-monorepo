import React from 'react';
import { ChordOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface ChordConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const ChordChart: React.ForwardRefExoticComponent<ChordConfig & React.RefAttributes<unknown>>;
export default ChordChart;
