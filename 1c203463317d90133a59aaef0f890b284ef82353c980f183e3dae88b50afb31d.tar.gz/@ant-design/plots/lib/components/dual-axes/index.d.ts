import React from 'react';
import { DualAxesOptions as G2plotConfig } from '@antv/g2plot';
import { BaseConfig } from '../../interface';
export interface DualAxesConfig extends Omit<G2plotConfig, 'tooltip'>, BaseConfig<G2plotConfig> {
}
declare const DualAxesChart: React.ForwardRefExoticComponent<DualAxesConfig & React.RefAttributes<unknown>>;
export default DualAxesChart;
